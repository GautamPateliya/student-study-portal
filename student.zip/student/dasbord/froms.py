from django import forms
from . models import *
from django.forms import widgets
from django.contrib.auth.forms import UserCreationForm

#this code is notesform
class NotesForm(forms.ModelForm):
    class Meta:
        model = Notes
        fields = ['title','description']
#this code is date input class
class DateInput(forms.DateInput):
    input_type ='date'
# this code is homeworkform
class HomeworkForm(forms.ModelForm):
    class Meta:
        model = Homework
        widgets = {'due':DateInput()}
        fields = ['subject','title','description','due','is_finished']

#this code is dashbordform 

class DashbordForm(forms.Form):
    text = forms.CharField(max_length=100,label="Enter Your Search : ")

#this is code todoform

class TodoForm(forms.ModelForm):
    class Meta:
        model = Todo# Add the model which is associated with the form
        fields = ['title', 'is_finished']

#this is convesionform 

class ConversionsForm(forms.Form):
    CHOICES = [('length','Length'),('mass','Mass')]
   # measurement = forms.ChoiceField(choices=CHOICES,widgets=forms.RadioSelect)
    measurement = forms.ChoiceField(choices=CHOICES,widget=forms.RadioSelect)

#this is code is lengthconversionform

class Lengthconversionform(forms.Form):
    CHOICES= [('yeard','Yaerd'),('foot','Foot')]
    input=forms.CharField(required=False,label=False,widget=forms.TextInput(attrs={'type':'number','placeholder':'Enter the Number'}))
    measure1=forms.CharField(
        label='',widget=forms.Select(choices=CHOICES)
    )
    measure2= forms.CharField(
        label='',widget=forms.Select(choices=CHOICES)
    )

#this code is conversionmassform

class ConversionMessform(forms.Form):
    CHOICES= [('pond','Pond'),('kilogram','Kilogram')]
    input=forms.CharField(required=False,label=False,widget=forms.TextInput(attrs={'type':'number','placeholder':'Enter the Number'}))
    measure1=forms.CharField(
        label='',widget=forms.Select(choices=CHOICES)
    )
    measure2= forms.CharField(
        label='',widget=forms.Select(choices=CHOICES)
    )
    
class UserRegistationForm(UserCreationForm):
    class Meta:
        model = User
        fields =['username','password1','password2']
